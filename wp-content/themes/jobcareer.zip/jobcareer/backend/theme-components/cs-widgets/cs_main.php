<?php

/**
 * Widgets Classes & Functions
 */
get_template_part('classes/widgets/class_jobcareer_recentposts');
get_template_part('classes/widgets/class_twitter_widget');
get_template_part('classes/widgets/class_facebook');
get_template_part('classes/widgets/class_flickr');
get_template_part('classes/widgets/class_mailchimp');
get_template_part('classes/widgets/class_ads_banner');
get_template_part('classes/widgets/class_jobcareer_opening_hours');
get_template_part('classes/widgets/class_jobcareer_promotions');
get_template_part('classes/widgets/class-wp-nav-menu-widget-chimp');
get_template_part('classes/widgets/class-fancy-menu');

