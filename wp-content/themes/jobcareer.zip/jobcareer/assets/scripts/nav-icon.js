// (function(){

// 	var unclicked = true;
// 	var navIcon = $('#nav-icon2');
// 	navIcon.on("click",function() {
// 		if (unclicked) {
// 		navIcon.addClass("open");
// 		unclicked = false;
// 	} else {
// 		navIcon.removeClass("open");
// 		unclicked = true;
// 	}
// });

// })();
