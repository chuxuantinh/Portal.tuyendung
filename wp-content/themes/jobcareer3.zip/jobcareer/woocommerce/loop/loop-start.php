<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates  
 */
?>

<div class="site-main">
<ul class="products">